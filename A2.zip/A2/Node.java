//From 212


//There is no need to modify this file
public class Node<T extends Comparable<? super T>> {

	protected T element;
	protected Node<T> left, right;

	public Node() {
		left = right = null;
	}

	public Node(T el) {
		this(el, null, null);
	}

	public Node(T el, Node<T> lt, Node<T> rt) {
		this.element = el;
		left = lt;
		right = rt;
	}

	public String toString() {
		String out = element.toString();
		out += " [L: " + (left == null ? null : left.element) + "] ";
		out += " [R: " + (right == null ? null : right.element) + "] ";
		return out;
	}

	public boolean isTerminal() {
		if (left == null && right == null) {
			return true;
		}
		return false;
	}
}