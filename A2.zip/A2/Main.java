import java.io.*;
import java.util.*;

public class Main {
    static Random rand = new Random();
    static String actual;
    static String FileName_Train = "";
    static String FileName_Test = "";
    static int constraint = 0;

    public static void main(String[] args) throws IOException {
       
        while(true){
            Scanner reader = new Scanner(System.in);
            System.out.println("Enter number a number : 1.Breast Cancer or 2.Tictactoe");
            int n = reader.nextInt();
            reader.close();

            if(n ==1){
                FileName_Train = "breast_cancer_Train.csv"; 
                FileName_Test = "breast_cancer_Test.csv";
                constraint = 85;//seed
                break;
            }
            else if(n == 2){
                FileName_Train = "tictactoe_Train.csv"; 
                FileName_Test = "tictactoe_Test.csv";
                constraint = 73;//seed
                break;

            }

        }
       



        int bestIndex = 0;
        int total = 0;
        float Accuracy = 0;
        int runs = 0;
        int skip = 0;
        int gens = 0;

        ArrayList<SA_GP<String>> trees = new ArrayList<SA_GP<String>>();

        for (int i = 0; i < 10; i++) {
            ArrayList<String> Arr = new ArrayList<String>();

            Arr.add("c");
            SA_GP<String> tree = new SA_GP<String>(actual);
            tree.root = tree.full(0, 3, Arr);
            trees.add(tree);
        }
        System.out.println("-------------------------------------Start-of-GP-------------------------------------");
        System.out.println("-----------------------Iterations of Accuracies without Mutations-------------------------");

        for (int i = 0; i < 10; i++) {
            total = 0;

            BufferedReader br = new BufferedReader(new FileReader(FileName_Train));

            ArrayList<String> Arr = readFile(br);
            while (!Arr.isEmpty()) {
                trees.get(i).replaceTerminals(trees.get(i).root, Arr);
                trees.get(i).setActual(actual);
                trees.get(i).isCorrect(trees.get(i).actual);
                total++;
                Arr = readFile(br);
            }
            if (trees.get(i).correctCount >= trees.get(bestIndex).correctCount) {
                bestIndex = i;
            }

           
            System.out.println( "Iteration " + (i+1) + ": " + (((float) trees.get(i).correctCount /(float) total) * 100) + "%");
            br.close();

        }
        Accuracy = (((float) trees.get(bestIndex).correctCount / (float) total) * 100);

        System.out.println("-----------------------Iterations of Accuracies without Mutations-------------------------");
        System.out.println();
        System.out.println("Best of the train accuracies: " + Accuracy + "%" );

        System.out.println();

        System.out.println("-------------------------------------Mutations-------------------------------------");

        SA_GP<String> tempBest = new SA_GP<>();
        tempBest.root = trees.get(bestIndex).clone();

        while (Accuracy < constraint) {
            runs++;
            trees.clear();
            for (int i = 0; i < 100; i++) {
                SA_GP<String> tempTree = new SA_GP<>();
                tempTree.root = tempBest.clone();
                tempTree.mutate();
                trees.add(tempTree);
            }
            for (int i = 0; i < trees.size(); i++) {
                total = 0;

                BufferedReader br = new BufferedReader(new FileReader(FileName_Train));

                ArrayList<String> Arr = readFile(br);
                while (!Arr.isEmpty()) {
                    trees.get(i).replaceTerminals(trees.get(i).root, Arr);
                    trees.get(i).setActual(actual);
                    trees.get(i).isCorrect(trees.get(i).actual);
                    total++;
                    Arr = readFile(br);
                }
                if (trees.get(i).correctCount >= trees.get(bestIndex).correctCount) {
                    bestIndex = i;
                }
                br.close();

            }
            if ((((float) trees.get(bestIndex).correctCount / (float) total) * 100) > Accuracy) {
                Accuracy = (((float) trees.get(bestIndex).correctCount / (float) total) * 100);
                tempBest = new SA_GP<>();
                tempBest.root = trees.get(bestIndex).clone();
                skip = 0;
                gens++;
            }
            if (skip >= 200) {
                int randInt = rand.nextInt(trees.size());
                Accuracy = (((float) trees.get(randInt).correctCount / (float) total) *100);
                tempBest = new SA_GP<>();
                tempBest.root = trees.get(randInt).clone();
                skip = 0;
                gens++;
            }
            skip++;
            System.out.println("Runs: " + runs + " - Generations: " + gens + " Mutation Result: " + Accuracy + "%"+ " Current step: " + skip);

                if(runs >= 2000){
                    break;
                }

        }

 

        total = 0;
        BufferedReader br = new BufferedReader(new FileReader(FileName_Test));
        ArrayList<String> Arr = readFile(br);
        while (!Arr.isEmpty()) {
            tempBest.replaceTerminals(tempBest.root, Arr);
            tempBest.setActual(actual);
            tempBest.isCorrect(tempBest.actual);
            total++;
            Arr = readFile(br);
        }
        System.out.println("-------------------------------------Mutations-------------------------------------"+"\n");
        System.out.println("-------------------------------------End-of-GP-------------------------------------");
        System.out.println();
        System.out.println("-------------------------------------Start-of-SA-------------------------------------");
        System.out.println("Test Accurracy: " + (((float) tempBest.correctCount /(float) total) * 100));
        System.out.println("-------------------------------------End-of-SA-------------------------------------");
        br.close();
    }

    static public ArrayList<String> readFile(BufferedReader br) throws IOException {
        ArrayList<String> Arr = new ArrayList<>();
        String line = br.readLine();
        if (line != null) {
            String[] data = line.split(",");
            for (int i = 0; i < 9; i++) {
                Arr.add(data[i]);
            }
            actual = data[9];
        }

        return Arr;
    }

  
}
