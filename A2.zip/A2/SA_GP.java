import java.io.*;
import java.util.*;

//@SuppressWarnings("unchecked")
public class SA_GP<T extends Comparable<? super T>> {
    protected Node<String> root = null;

    static String[] ops = { "+", "-", "*", "/" };
    public Random rand;
    public String actual;
    public int correctCount;
    public int index = 0;
    protected int terminals;

    public SA_GP() {
        rand = new Random();
        correctCount = 0;
        actual = "";
        terminals = 0;
    }

    public SA_GP(Random rand) {
        this.rand = rand;
        correctCount = 0;
        actual = "";
        terminals = 0;
    }

    public SA_GP(Node<String> root) {
        rand = new Random();
        this.root = root;
        correctCount = 0;
        actual = "";
        terminals = 0;
    }

    public SA_GP(String actual) {
        rand = new Random();
        this.actual = actual;
        correctCount = 0;
        terminals = 0;
    }

    public SA_GP(int terminals) {
        rand = new Random();
        this.actual = "";
        correctCount = 0;
        this.terminals = terminals;
    }

    public void setActual(String actual) {
        this.actual = actual;
    }

    public int getTerminals() {
        return terminals;
    }

    public void setTerminals(int terminals) {
        this.terminals = terminals;
    }

    public int countTerminals(Node<String> root) {
        if (root == null) {
            return 0;
        }
        if (root.isTerminal()) {
            return 1;
        }
        return countTerminals(root.left) + countTerminals(root.right);
    }

    public static void main(String[] args) throws IOException {

    }

    public void mutate() {
        if (root == null) {
            root = new Node<>();
        } else {
            Node<String> previous = null;
            Node<String> p = root;
            SA_GP<String> newTree = makeSubtree();
            Random rand2 = new Random();

            while (!p.isTerminal()) {
                previous = p;
                int randIndex = rand2.nextInt(2);
                if (randIndex == 0) {
                    p = p.left;
                } else {
                    p = p.right;
                }
            }
            int randIndex = rand2.nextInt(2);
            if (randIndex == 0) {
                previous.left = newTree.root;
            } else {
                previous.right = newTree.root;
            }
        }
        this.setTerminals(this.countTerminals(root));

    }

    public SA_GP<String> makeSubtree() {
        ArrayList<String> q = new ArrayList<String>();
        q.add("c");
        Random rand2 = new Random();
        int randDepth = rand2.nextInt(3) + 1;
        SA_GP<String> tempTree = new SA_GP<String>();
        tempTree.root = tempTree.full(0, randDepth, q);

        return tempTree;
    }

    public void findRandTerminal(Node<String> node, Node<String> sub) {

        if (!node.isTerminal()) {
            Random rand2 = new Random();
            int randIndex = rand2.nextInt(2);
            if (randIndex == 0) {
                if (node.left != null) {
                    findRandTerminal(node.left, sub);
                }
                findRandTerminal(node.right, sub);
            } else {
                if (node.right != null) {
                    findRandTerminal(node.right, sub);
                }
                findRandTerminal(node.left, sub);
            }
        }
        node = sub;
    }

    public Node<String> full(int depth, int maxDepth, ArrayList<String> q) {
        Node<String> node = new Node<String>();
        if (depth < maxDepth) {
            int upperbound = 4;
            int int_random = rand.nextInt(upperbound);
            node.element = ops[int_random];
            node.left = full(depth + 1, maxDepth, q);
            node.right = full(depth + 1, maxDepth, q);
        } else {
            if (index >= q.size()) {
                index = 0;
            }
            node.element = q.get(index++);
            this.terminals++;
        }
        return node;
    }

    public static void fitness(Node<String> node) {

    }

    public static void printTree(SA_GP<String> tree) {
        String result;
        System.out.println("Binary Search Tree Content:");
        result = tree.inorder(tree.root);
        System.out.println(result);
    }

    public String inorder(Node<T> node) {
        boolean verbose = true;
        if (node != null) {
            String result = "";
            result += inorder(node.left);
            if (verbose) {
                result += node.toString() + "\n";
            } else {
                result += node.element.toString() + " ";
            }
            result += inorder(node.right);
            return result;
        }
        return "";
    }

    public float result(Node<String> node) {
        if (node == null) {
            return 0;
        } else {
            if (node.element.equals("+")) {
                if (node.left == null) {
                    return result(node.right);
                } else if (node.right == null) {
                    return result(node.left);
                } else {
                    return result(node.left) + result(node.right);
                }
            } else if (node.element.equals("-")) {
                if (node.left == null) {
                    return result(node.right);
                } else if (node.right == null) {
                    return result(node.left);
                } else {
                    return result(node.left) - result(node.right);
                }
            } else if (node.element.equals("*")) {
                if (node.left == null) {
                    return result(node.right);
                } else if (node.right == null) {
                    return result(node.left);
                } else {
                    return result(node.left) * result(node.right);
                }
            } else if (node.element.equals("/")) {
                if (node.left == null) {
                    return result(node.right);
                } else if (node.right == null) {
                    return result(node.left);
                } else {
                    Float right = result(node.right);
                    if (right == 0) {// checks for devision by zero
                        return 0;
                    } else {
                        return result(node.left) / right;
                    }
                }
            } else {
                return Float.parseFloat(node.element.toString());
            }
        }
    }

    public Node<String> clone() {
        SA_GP<String> copy = new SA_GP<String>();
        copy.root = new Node<String>();
        cloneHelper(this.root, copy.root);
        return copy.root;
    }

    public void cloneHelper(Node<String> old, Node<String> node) {

        node.element = old.element;
        if (old.left != null) {
            node.left = new Node<String>();
            cloneHelper(old.left, node.left);
        }
        if (old.right != null) {
            node.right = new Node<String>();
            cloneHelper(old.right, node.right);
        }
    }

    public void replaceTerminals(Node<String> node, ArrayList<String> q) {
        if (node.isTerminal()) {
            if (index >= q.size()) {
                index = 0;
            }
            node.element = q.get(index++);
        } else {
            if (node.left != null) {
                replaceTerminals(node.left, q);
            }
            if (node.right != null) {
                replaceTerminals(node.right, q);
            }
        }

    }

    public boolean isCorrect(String actual) {
        int sign;
        int actual_int = Integer.parseInt(actual);
        Float result = result(root);
        if (result < 0.5) {
            sign = 0;
        } else {
            sign = 1;
        }
        if (sign == actual_int) {
            correctCount++;
            return true;
        } else {
            return false;
        }
    }

    public void clearTree() {
        root = null;
    }
}