import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class DataClass {
    ArrayList<Float> data;
    float[] expected;

    DataClass(ArrayList<Float> d, float[] e){
        data = d;
		expected = e;
    }
    
    public int expectedIndex(){
		float max = Float.MIN_VALUE;
		int maxIndex = -1;
		for(int i = 0; i < expected.length; ++i){
			if(expected[i] > max){
				max = expected[i];
				maxIndex = i;
			}
		}
		return maxIndex;
	}
    
    public static ArrayList<DataClass> createDataSetFromFile(String filename){
        ArrayList<DataClass> dataSet = new ArrayList<DataClass>();
        try{
            File file = new File(filename);
            FileReader fr = new FileReader(file);
            BufferedReader br = new BufferedReader(fr);
            String line = "";
            String[] tempArr;
            while((line = br.readLine()) != null) {
                tempArr = line.split(",");
                char e = 'B';
                ArrayList<Float> d = new ArrayList<Float>();
                for (int i = 0; i < tempArr.length; i++) {
                    if(i == 0 ){
                        e = tempArr[i].charAt(tempArr[i].length()-1);
                    }
                    else{
                        Float number = Float.parseFloat(tempArr[i]);
                        d.add(number);
                    }
               }
               DataClass temp = new DataClass(d,expectedOutput(e));
               dataSet.add(temp);
            }   
        }
        catch(IOException e) {
            e.printStackTrace();
        }
        return dataSet;
    }
    public static float[] expectedOutput(char group){
		if(group == 'L') return new float[] {1,0,0};
		if(group == 'B') return new float[] {0,1,0};
		if(group == 'R') return new float[] {0,0,1};
		return null;
	}
    @Override
    public String toString() {
        // TODO Auto-generated method stub
        return data.toString() + "Expect: " + expected;
    }
}
