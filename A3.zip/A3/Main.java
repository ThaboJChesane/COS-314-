import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

	

		
		Scanner Object = new Scanner(System.in);  
   	 	System.out.println("Enter the minumuim weight: ");

		float MinimumWeight = Float.parseFloat(Object.nextLine());
		System.out.println("Enter the maximuim weight: ");

		float MaximumWeight = Float.parseFloat(Object.nextLine());
		System.out.println("Enter the learning rate: ");

		float learning_rate = Float.parseFloat(Object.nextLine());
		System.out.println("Enter the accuracy threshold: ");

		float accuracy_threshold = Float.parseFloat(Object.nextLine());
		System.out.println("Enter the training file: ");

		String train = Object.nextLine();
		System.out.println("Enter the validation file:  ");
		String validate= Object.nextLine();
		System.out.println("Enter the test file:  ");
		String test = Object.nextLine();
		

		Driver network = new Driver(MinimumWeight,MaximumWeight);
		network.train(train,validate,accuracy_threshold,learning_rate);
		network.test(test);

		writeToFile("output.txt", network.summary());

	}

	public static float[] parseParamFile(String inFile){
	    float[] result = new float[4];
		try{
            File file = new File(inFile);
            FileReader fr = new FileReader(file);
            BufferedReader br = new BufferedReader(fr);
            String line = "";
            int x=0;
            while((line = br.readLine()) != null) {
            
                Float number = Float.parseFloat(line);
                result[x++] = number;
            }   
        }catch(IOException e) {
            e.printStackTrace();
        }

		return result;
	}
    public static void writeToFile(String filename, String content){	
		if(content.length() == 0) 
            return;
		try {
			FileWriter myWriter = new FileWriter(filename);		
            myWriter.write(content);
			myWriter.close();	
        } catch (IOException e) {
        System.out.println("File could not be written to: " + filename);
			e.printStackTrace();		
        }
	}
}
