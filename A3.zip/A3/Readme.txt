
In order to run the programme you can open the A3 folder in your command line and use the following commands:


java -jar Assignment3u20507102.jar

Output results will be stored in output.txt

Enter the following for terminal input:

Enter the minumuim weight: 
-4
Enter the maximuim weight: 
4
Enter the learning rate: 
0.05
Enter the accuracy threshold: 
0.93
Enter the training file:
train.data
Enter the validation file:
validate.data
Enter the test file:  
test.data
