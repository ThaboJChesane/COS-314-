import java.util.ArrayList;

public class Layer {
    public Neuron[] neurons;
    public static Layer createLayer(int prevNeuronCount, int neuronCount){
		Layer layer = new Layer();
		layer.neurons = new Neuron[neuronCount];
		for(int n = 0; n < neuronCount; ++n){
			float[] weights = Algorithms.RandomFloatArray(prevNeuronCount,Neuron.MinimumWeight, Neuron.MaximumWeight, true);
			float bias = Algorithms.RandomSignedFloat(0, 1);
			layer.neurons[n] = Neuron.createNeuron(weights, bias);
		}
		return layer;
	}

	public static Layer createInputLayer(ArrayList<Float> data){
		Layer layer = new Layer();
		layer.neurons = new Neuron[data.size()];
		for(int n = 0; n < data.size(); ++n){
			layer.neurons[n] = Neuron.createInputNeuron(data.get(n));
		}
		return layer;
	}

	public String toString(){
		return "Layer( n:"+ neurons.length +" )";
	}

	public int bestNeuronIndex(){
		float max = Float.MIN_VALUE;
		int maxIndex = -1;
		for(int n = 0; n < neurons.length; ++n){
			if(neurons[n].value > max){
				max = neurons[n].value;
				maxIndex = n;
			}
		}
		return maxIndex;
	}

}
