import java.util.*;

public class BFS {
    public BFS() {
    }

    public Node bfs(Node root, String goal) {
        Queue<Node> open = new LinkedList<Node>();
        ArrayList<Node> closed = new ArrayList<Node>();

        Node currentNode = root;

        if (!open.isEmpty()) {
            open.add(currentNode);
            while (!open.isEmpty()) 
            {
                System.out.println(closed.size());
                currentNode = open.remove();
                if (currentNode != null) {
                    // System.out.println(currentNode.getBoardString());
                    if (currentNode.getBoardString().equals(goal)) {
                        return currentNode;
                    }

                    for (Node child : currentNode.getNeighbours()) {
                        if(!Ocontain(open, child) && Ccontain(closed, child))
                            open.add(child);
                    }
                }
            }
        }
        return null;
    }

    public boolean Ccontain(ArrayList<Node> closed, Node child)
    {
        for(Node node : closed)
        {
            if (node.getBoardString().equals(child.getBoardString())) 
            {
                return true;
            }   
        }
        return false;
    }

    public boolean Ocontain(Queue<Node> open, Node child)
    {
        for(Node node : open)
        {
            if (node.getBoardString().equals(child.getBoardString())) 
            {
                return true;
            }   
        }
        return false;
    }

}
