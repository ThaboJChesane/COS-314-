import java.util.*;

import javax.swing.JOptionPane;

public class Main {

    public static Node bfs(Node root, String goal) {
        Queue<Node> open = new LinkedList<Node>();
        ArrayList<Node> closed = new ArrayList<Node>();

        Node currentNode = root;

        if (true) {
            open.add(currentNode);
            while (!open.isEmpty()) 
            {
                currentNode = open.remove();
                
                    if (currentNode.getBoardString().equals(goal)) 
                    {
                       
                        return currentNode;
                    }

                    for (Node child : currentNode.getNeighbours()) 
                    {
                        if(child != null && !Ocontain(open, child) && !Ccontain(closed, child))
                        {
                            open.add(child);
                        } 
                            
                    }
                    closed.add(currentNode);
               
            }
        }
        return null;
    }


    public static Node bestfirst(Node root, String goal) {
        PriorityQueue<Node> open = new PriorityQueue<Node>();
        ArrayList<Node> closed = new ArrayList<Node>();

        Node currentNode = root;

        if (true) {
            open.add(currentNode);
            while (!open.isEmpty()) 
            {
                currentNode = open.remove();
                
                    if (currentNode.getBoardString().equals(goal)) 
                    {
                        
                        return currentNode;
                    }

                    for (Node child : currentNode.getNeighbours()) 
                    {
                        if(child != null && !POcontain(open, child) && !Ccontain(closed, child))
                        {
                          
                            open.add(child);
                        } 
                            
                    }
                    closed.add(currentNode);
                
            }
        }
        return null;
    }

    public static Node hillclimb(Node root, String goal) {
        ArrayList<Node> closed = new ArrayList<Node>();

        Node currentNode = root;
        currentNode.setHcost();
            
            while (true) 
            {
               
                    if (currentNode.getBoardString().equals(goal)) 
                    {
                        
                        return currentNode;
                    }

                    Node temp = currentNode;

                    for (Node child : currentNode.getNeighbours()) 
                    {
                        if(child != null && !Ccontain(closed, child))
                        {
                            
                            if(child.hcost <= temp.hcost)
                            {
                                temp = child;
                            }
                        } 
                            
                    }
                    if(temp == currentNode)
                    {
                        return temp;
                    }
                    currentNode = temp;
                    closed.add(currentNode);
                
            }
    }

    public static Node A(Node root, String goal) {
        PriorityQueue<Node> open = new PriorityQueue<Node>();
        ArrayList<Node> closed = new ArrayList<Node>();

        Node currentNode = root;

        if (true) {
            open.add(currentNode);
            while (!open.isEmpty()) 
            {
                currentNode = open.remove();
                
                    if (currentNode.getBoardString().equals(goal)) 
                    {
                        
                        return currentNode;
                    }

                    for (Node child : currentNode.getNeighbours()) 
                    {
                        if(child != null && !POcontain(open, child) && !Ccontain(closed, child))
                        {
                            child.hcost = child.hcost + child.depth;
                           
                            open.add(child);
                        } 
                            
                    }
                    closed.add(currentNode);
               
            }
        }
        return null;
    }

    public static boolean Ccontain(ArrayList<Node> closed, Node child)
    {
        for(Node node : closed)
        {
            if (node.getBoardString().equals(child.getBoardString())) 
            {
                return true;
            }   
        }
        return false;
    }

    public static boolean Ocontain(Queue<Node> open, Node child)
    {
        for(Node node : open)
        {
            if (node.getBoardString().equals(child.getBoardString())) 
            {
                return true;
            }   
        }
        return false;
    }

    public static boolean POcontain(PriorityQueue<Node> open, Node child)
    {
        for(Node node : open)
        {
            if (node.getBoardString().equals(child.getBoardString())) 
            {
                return true;
            }   
        }
        return false;
    }

    


    public static void main(String[] args) {
        List<List<Integer>> Starts = new ArrayList<>();
        List<Integer> s1 = new ArrayList<>(List.of(1, 2, 3, 8, 0, 4, 7, 6, 5));
        List<Integer> s2 = new ArrayList<>(List.of(1, 2, 3, 8, 0, 4, 7, 6, 5));
        List<Integer> s3 = new ArrayList<>(List.of(1, 2, 3, 8, 0, 4, 7, 6, 5));
        List<Integer> s4 = new ArrayList<>(List.of(1, 3, 4, 8, 0, 5, 7, 2, 6));
        List<Integer> s5 = new ArrayList<>(List.of(2, 3, 1, 7, 0, 8, 6, 5, 4));
        List<Integer> s6 = new ArrayList<>(List.of(2, 3, 1, 8, 0, 4, 7, 6, 5));
        List<Integer> s7 = new ArrayList<>(List.of(1, 2, 3, 8, 0, 4, 7, 6, 5));
        List<Integer> s8 = new ArrayList<>(List.of(1, 2, 3, 8, 0, 4, 7, 6, 5));
        List<Integer> s9 = new ArrayList<>(List.of(8, 7, 6, 1, 0, 5, 2, 3, 4));
        List<Integer> s10 = new ArrayList<>(List.of(8, 6, 7, 2, 5, 4, 3, 0, 1));

        List<List<Integer>> Goals2 = new ArrayList<>();
        List<Integer> gg1 = new ArrayList<>(List.of(1, 3, 4, 8, 6, 2, 7, 0, 5));
        List<Integer> gg2 = new ArrayList<>(List.of(2, 8, 1, 0, 4, 3, 7, 6, 5));
        List<Integer> gg3 = new ArrayList<>(List.of(2, 8, 1, 4, 6, 3, 0, 7, 5));
        List<Integer> gg4 = new ArrayList<>(List.of(1, 2, 3, 8, 0, 4, 7, 6, 5));
        List<Integer> gg5 = new ArrayList<>(List.of(1, 2, 3, 8, 0, 4, 7, 6, 5));
        List<Integer> gg6 = new ArrayList<>(List.of(1, 2, 3, 8, 0, 4, 7, 6, 5));
        List<Integer> gg7 = new ArrayList<>(List.of(2, 3, 1, 8, 0, 4, 7, 6, 5));
        List<Integer> gg8 = new ArrayList<>(List.of(5, 6, 7, 4, 0, 8, 3, 2, 1));
        List<Integer> gg9 = new ArrayList<>(List.of(1, 2, 3, 8, 0, 4, 7, 6, 5));
        List<Integer> gg10 = new ArrayList<>(List.of(1, 2, 3, 4, 5, 6, 7, 8, 0));

        Starts.add(s1);
        Starts.add(s2);
        Starts.add(s3);
        Starts.add(s4);
        Starts.add(s5);
        Starts.add(s6);
        Starts.add(s7);
        Starts.add(s8);
        Starts.add(s9);
        Starts.add(s10);

        Goals2.add(gg1);
        Goals2.add(gg2);
        Goals2.add(gg3);
        Goals2.add(gg4);
        Goals2.add(gg5);
        Goals2.add(gg6);
        Goals2.add(gg7);
        Goals2.add(gg8);
        Goals2.add(gg9);
        Goals2.add(gg10);
      


        for (Integer integer : Starts.get(0)) {
            System.out.print(integer);
        }
        System.out.println();
        ;
    

        Integer[] index = { 4, 4, 4, 4, 4, 4, 4, 4, 4, 7 };

        List<String> Goals = new ArrayList<>();
        

        String g1 = "134862705";
        String g2 = "281043765";
        String g3 = "281463075";
        String g4 = "123804765";
        String g5 = "123804765";
        String g6 = "123804765";
        String g7 = "231804765";
        String g8 = "567408321";
        String g9 = "123804765";
        String g10 = "123456780";

        Goals.add(g1);
        Goals.add(g2);
        Goals.add(g3);
        Goals.add(g4);
        Goals.add(g5);
        Goals.add(g6);
        Goals.add(g7);
        Goals.add(g8);
        Goals.add(g9);
        Goals.add(g10);


        Scanner input = new Scanner(System.in);
    	
        System.out.print("Please enter a number "+"\n" + "1.BFS"+ "\n" +"2.Best First" + "\n" + "3.Hillclimb" +"\n" + "4.A*" +"\n");
        int number = input.nextInt();
       

        // closing the scanner object
        input.close();

        for (int i = 0; i < 10; i++) {

            if(number == 1){
            long milStart = System.currentTimeMillis();
            Node root = new Node(Starts.get(i), "", index[i], 0, Goals2.get(i) );
            Node target = bfs(root, Goals.get(i));
           
            int n = i + 1;
            System.out.println("********************Instance " + n + "********************" );
            System.out.println("--------------------BFS--------------------");
            System.out.print(root.getBoardString() + " --> " + Goals.get(i) + " ");
            System.out.println("Time: " + ((System.currentTimeMillis() - milStart)) +
                    "ms" + " steps: " + target.getDepth());
        }


        if(number == 2){
           long milStart = System.currentTimeMillis();
           Node root = new Node(Starts.get(i), "", index[i], 0, Goals2.get(i) );
           Node target = bestfirst(root, Goals.get(i));

           int n = i + 1;
           System.out.println("********************Instance " + n + "********************" );
            System.out.println("--------------------Best First--------------------");
            System.out.print(root.getBoardString() + " --> " + Goals.get(i) + " ");
            System.out.println("Time: " + ((System.currentTimeMillis() - milStart)) +
                            "ms" + " steps: " + target.getDepth());
        }

        if(number == 3){
            long milStart = System.currentTimeMillis();
           Node root = new Node(Starts.get(i), "", index[i], 0, Goals2.get(i) );
           Node target = hillclimb(root, Goals.get(i));
                                     
           int n = i + 1;
           System.out.println("********************Instance " + n + "********************" );
            System.out.println("--------------------Hillclimb--------------------");
            System.out.print(root.getBoardString() + " --> " + Goals.get(i) + " ");
             System.out.println("Time: " + ((System.currentTimeMillis() - milStart)) +
                             "ms" + " steps: " + target.getDepth());

        }

        if(number == 4){
            long milStart = System.currentTimeMillis();
           Node root = new Node(Starts.get(i), "", index[i], 0, Goals2.get(i) );
           Node target = A(root, Goals.get(i));
                    
           int n = i + 1;
           System.out.println("********************Instance " + n + "********************" );
         System.out.println("--------------------A*--------------------");
         System.out.print(root.getBoardString() + " --> " + Goals.get(i) + " ");
         System.out.println("Time: " + ((System.currentTimeMillis() - milStart)) +
                                "ms" + " steps: " + target.getDepth());

    }
        System.out.println();
        System.out.println();
            
        }

        
    }
}