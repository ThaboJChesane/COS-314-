import java.util.*;

public class Node implements Comparable<Node> {
    public Node(List<Integer> inBoard, String inPath, int xIn, int dIn, List<Integer> goalstate) {

        this.path = inPath;
        this.x = xIn;
        this.Board = inBoard;
        this.upNode = null;
        this.downNode = null;
        this.leftNode = null;
        this.rightNode = null;
        this.depth = dIn;
        this.goal = goalstate;
    }

    public List<Integer> cloneBoard() {
        List<Integer> tempBoard = new ArrayList<>();
        for (int i = 0; i < 9; i++) {
            tempBoard.add(this.getBoard().get(i));
        }
        return tempBoard;
    }

    public List<Integer> getBoard() {
        return this.Board;
    }

    public Node makeRight() {
        List<Integer> tempBoard = cloneBoard();

        if (x != 0 && x != 3 && x != 6) {
            tempBoard.set(this.x - 1, this.Board.get(this.x));
            tempBoard.set(this.x, this.Board.get(this.x - 1));
            this.rightNode = new Node(tempBoard, this.path + "right ", this.x - 1, this.depth + 1, this.goal);
            this.rightNode.leftNode = this;
            this.rightNode.setHcost();
            return this.rightNode;
        }
        return null;

    }

    public Node makeLeft() {
        List<Integer> tempBoard = cloneBoard();

        if (this.x != 2 && this.x != 5 && this.x != 8) {
            tempBoard.set(this.x + 1, this.Board.get(this.x));
            tempBoard.set(this.x, this.Board.get(this.x + 1));
            this.leftNode = new Node(tempBoard, this.path + "left ", this.x + 1, this.depth + 1, this.goal);
            this.leftNode.rightNode = this;
            this.leftNode.setHcost();
            return this.leftNode;
        }
        return null;

    }

    public Node makeUp() {
        List<Integer> tempBoard = cloneBoard();

        if (x < 6) {
            tempBoard.set(this.x + 3, this.Board.get(this.x));
            tempBoard.set(this.x, this.Board.get(this.x + 3));

            this.upNode = new Node(tempBoard, this.path + "up ", this.x + 3, this.depth + 1, this.goal);
            this.upNode.downNode = this;
            this.upNode.setHcost();
            return this.upNode;
        }
        return null;

    }

    public Node makeDown() {
        List<Integer> tempBoard = cloneBoard();

        if (x > 2) {
            tempBoard.set(this.x - 3, this.Board.get(this.x));
            tempBoard.set(this.x, this.Board.get(this.x - 3));

            this.downNode = new Node(tempBoard, this.path + "down ", this.x - 3, this.depth + 1, this.goal);
            this.downNode.upNode = this;
            this.downNode.setHcost();
            return this.downNode;
        }
        return null;
    }

    public String getBoardString() {
        String temp = "";
        for (int i = 0; i < 9; i++) {
            temp += this.Board.get(i);
        }
        return temp;
    }

    public Node getdownNode() {
        return this.downNode;
    }

    public Node getupNode() {
        return this.upNode;
    }

    public Node getleftNode() {
        return this.leftNode;
    }

    public Node getrightNode() {
        return this.rightNode;
    }

    public String getPath() {
        return this.path;
    }

    public int getDepth() {
        return this.depth;
    }

    public void setHcost() {
        int cX = 0;
        int cY = 0;
        int gX = 0;
        int gY = 0;
        int xDiff = 0;
        int yDiff = 0;

        for (int i = 0; i < 9; i++) {
            for (int x = 0; x < 3; x++) {
                for (int y = 0; y < 3; y++) {
                    if (this.Board.get((x * 3) + y) == i) {
                        cX = x;
                        cY = y;
                    }
                    if (this.goal.get((x * 3) + y) == i) {
                        gX = x;
                        gY = y;
                    }
                }
            }
            xDiff = Math.abs(cX - gX);
            yDiff = Math.abs(cY - gY);
            this.hcost += xDiff + yDiff;
        }
        // for(int i = 0; i < 9; i++)
        // {
        // if(Board.get(i) != goal.get(i))
        // {
        // hcost = hcost + 1;
        // }
        // }
    }

    public void setGoal(List<Integer> goalstate) {
        this.goal = goalstate;
    }

    public List<Integer> getGoal() {
        return this.goal;
    }

    public List<Node> getNeighbours() {
        Neighbours.add(this.makeUp());
        Neighbours.add(this.makeLeft());
        Neighbours.add(this.makeDown());
        Neighbours.add(this.makeRight());
        return Neighbours;
    }

    List<Integer> Board = new ArrayList<>();
    List<Integer> goal = new ArrayList<>();
    List<Node> Neighbours = new ArrayList<>();

    Node leftNode;
    Node rightNode;
    Node upNode;
    Node downNode;

    int x;
    int y;
    int hcost = 0;
    String path;
    int depth;

    @Override
    public int compareTo(Node node) {
        if (hcost < node.hcost) {
            return -1;
        }
        return 1;
    }

}